from pathlib import Path
import cadquery as cq
from cadquery import exporters
import trimesh, math,json,zipfile,shutil
P=Path('/mnt/data/ArrowsAlpha_LiveTray_v07_no_screws_final')
D=P/'STL';S=P/'STEP';T=P/'TEST';
for p in (D,S,T):p.mkdir(parents=True,exist_ok=True)
W=110;DEP=162;FW=6; d=3.0

def box(a,b,c,x=0,y=0,z=0):return cq.Workplane('XY').box(a,b,c).translate((x,y,z)).val()
def xz_prism(points,y0,yd):return cq.Workplane('XZ',origin=(0,y0,0)).polyline(points).close().extrude(-yd).val()
def clean(s):return s.clean()
def save(s,path,dir=D):
 b=s.BoundingBox();s=s.translate((110-(b.xmin+b.xmax)/2,110-(b.ymin+b.ymax)/2,-b.zmin))
 f=dir/path;exporters.export(s,str(f),exportType='STL',tolerance=.07,angularTolerance=.25)
 m=trimesh.load(f,force='mesh'); print(path,m.extents,m.is_watertight,'vol',round(m.volume))
 assert m.is_watertight and m.volume>0 and all(v<=220.01 for v in m.extents)
 return f

def step(s,filename):exporters.export(s,str(S/filename),exportType='STEP')

# snap-free captured side-tray rails, slide on along Y from front, end stops built into central deck.
# no thin flexible tabs: printed geometric stops + snug fit + two clip pads on rail at end
# profile cross-section: T rail attached at center edges, dimensions about 6.5mm outboard.
# rail shaft extends outward at z 3-7, head extends wider x at z6-10.

def rail_geom(side,ylen=135):
 # center is 110 wide -> x +-55. tongue protrudes from sides to +/-63.5
 x0=side*57.5
 stem=box(5.5,ylen,3.2,x0,2,5.5)
 head=box(9.0,ylen,3.0,side*60.5,2,8.55)
 return stem.fuse(head).clean()

def channel_cut(side):
 # pocket in side tray seam: channel shape inside its edge, approx 0.3mm per side clearance
 return box(6.1,140,3.8,side*57.5,4,5.5).fuse(box(9.6,140,3.6,side*60.5,4,8.6)).clean()

# Central slab 110x162, front y -81, back +81
# Floor 6mm, printing from bottom; underside integrated 70x52x9 blade,
# attached directly to underside center face with solid tapered wedge.
center=box(110,162,6,0,0,12) # slab from z9 to15
blade=box(70,52,9,0,0,4.5) # lower clamp spans 0..9 mm
# blade edges very lightly rounded for clamp comfort
try:blade=cq.Workplane(obj=blade).edges('|Z').fillet(1.2).val()
except:pass
center=center.fuse(blade)
# load distributing gussets (side of grip and near front/back)
for x in (-27,27):
 for y in (-23,23): center=center.fuse(box(12,12,3,x,y,10.5))
# Side integration tongue rails under seam; rear and front stop walls
for side in (-1,1):
 center=center.fuse(rail_geom(side,135))
# Phone dock sits behind drinks but centered: receiving printed 96x65 test part.
# phone holder base is 96 x65; side lower gripping ledges engage 4mm base plate
# install from back (+Y) sliding toward -Y. No new independent pieces.
# Dock located y roughly 6, extending y [-26.5,+38.5]. Plate sits on center slab z15.
# Two guides along x +/-48, and top retaining lips above base at z18.7
for side in (-1,1):
 # side rail external to 96 mm wide plate
 center=center.fuse(box(2.8,66,6,side*49.6,6,18))
 # retaining shelf inward 2mm, bottom clearance 4.25mm above floor
 center=center.fuse(box(2.2,58,2.0,side*47.4,3.5,20.3))
# insertion limit at front, no rear stop (slide into front edge)
center=center.fuse(box(98,3.0,5.2,0,-27.7,17.6))
# two narrow rear teeth prevent simple fall-out if rotated; can be removed with gentle lifting
# eliminate for safety if binding. Most load transmitted into shelf.
center=clean(center)
save(center,'01_CENTER_WITH_70MM_TRIPOD_GRIP_AND_PHONE_DOCK.stl');step(center,'01_CENTER_INTEGRATED.step')

# Side trays: measured effective inner footprint 108x154, approx 115x162 outer.
# plate extends from x55..170, y=-81..81. Open seam edge. female channels in protruding lip.
for side,nm in [(-1,'LEFT'),(1,'RIGHT')]:
 p=box(115,162,6,side*112.5,0,12) # z9..15
 # front / rear / outer rim, height 9 mm
 for y in (-79.2,79.2):p=p.fuse(box(115,3.6,9,side*112.5,y,19.5))
 p=p.fuse(box(3.6,162,9,side*168.2,0,19.5))
 # seam slide channel: side section removed (T profile); no hole through upper surface except mouth on seam
 p=p.cut(channel_cut(side))
 # add short track end bridge rear; blocks extrusion to reduce inadvertent sliding
 # notch end: channel opens from front y<-66 and stops at y+74; no front closure
 p=clean(p)
 save(p,f'02_{nm}_TABLE_90x140_KEYPAD.stl');step(p,f'02_{nm}_TABLE.step')

# Frontal central suspended cup holder; fastener-free C-clips over the 6mm central deck edge.
# Deck is z9..15 and front edge y=-81. The two hanger straps span y=-80..-37
# and carry beverage load over >40mm lever arm. U-shaped jaw clamps deck from BOTH sides.
# PETG creep and tripod tipping under a full drink remain unvalidated; use empty only initially.
OD=88.; ID=80.; cy=-118.; top_z=-9.; bottom_z=-54.
# Top ring and bottom open mesh; light basket stays below central tray and phone screen.
cup=cq.Workplane('XY').circle(OD/2).circle(ID/2).extrude(7).translate((0,cy,top_z)).val()
cup=cup.fuse(cq.Workplane('XY').circle(OD/2).circle(ID/2).extrude(5).translate((0,cy,bottom_z)).val())
for a in range(10):
 theta=2*math.pi*a/10
 x=(OD/2-2.5)*math.cos(theta);y=cy+(OD/2-2.5)*math.sin(theta)
 cup=cup.fuse(box(6,6,top_z-bottom_z+5,x,y,(top_z+bottom_z+5)/2))
for x in [-24,-8,8,24]: cup=cup.fuse(box(5,70,4,x,cy,bottom_z+2))
for y in [cy-21,cy,cy+21]:cup=cup.fuse(box(68,5,4,0,y,bottom_z+2))
# cup hanger: two stanchions rise from front edge of basket. Connect to sleeve about tray front lip.
for x in [-24,24]:
 # vertical structural strap from the ring behind the cup to the top of tray
 cup=cup.fuse(box(12,7,36,x,-85,-1.5)) # from -19.5 to +16.5
 # top overlapping arm above the 6 mm tabletop: z15.35..18.5
 cup=cup.fuse(box(13,45,3.2,x,-60.5,16.9)) # y -83..-38
 # lower arm below table: z5.7..8.55; leaves .45 mm slot each side of z9..15 slab
 cup=cup.fuse(box(13,29,2.8,x,-67.5,7.15)) # y -82..-53
 # connector behind lip joins the two jaws OUTSIDE deck at y=-85
 cup=cup.fuse(box(13,5,11,x,-84.3,12.1))
# slider does not lock against being pulled forwards, but 45 mm overlap provides support.
cup=clean(cup)
save(cup,'03_FRONT_CENTER_CUP_HOLDER_SLIDE_ON_EMPTY_FIRST.stl');step(cup,'03_CUP.step')

readme='''# arrows alpha 配信トレー v0.7 ネジなし・本体印刷版

## 印刷対象 — 本体4パーツのみ
1. `STL/01_CENTER_WITH_70MM_TRIPOD_GRIP_AND_PHONE_DOCK.stl` — 中央トレー・70mm幅三脚ホルダー固定プレート一体型
2. `STL/02_RIGHT_TABLE_90x140_KEYPAD.stl` — テンキー用右テーブル
3. `STL/02_LEFT_TABLE_90x140_KEYPAD.stl` — 左側テーブル
4. `STL/03_FRONT_CENTER_CUP_HOLDER_SLIDE_ON_EMPTY_FIRST.stl` — 中央手前のドリンクホルダー

本体とは別に印刷済みのarrows alpha保持部（底板96×65mm）を上面の差し込みレールへセットします。
独立したピン・ネジ・ナット・接着剤は設計上不要です。新たな接続テスト片は不要。

## 組立
- 中央裏側の70×52×9mmプレートを写真の既存三脚ホルダーで左右から挟んで固定。
- 印刷済みのスマホ保持部（幅96×奥行65×底板4mm想定）を、中央上面の2本のL字レールに後方から前向きにスライド。無理な力はかけず、寸法が合わなければ止める。
- 右・左テーブルを中央両側のT字レールの**手前から奥へ**スライド。レールと溝は0.3mm程度のすきまを見込んだ設計です。別途機械的なロックはありません。
- ドリンクホルダーは中央前縁の天板を上下から挟む2本のC形ハンガーで差し込む。専用の固定ねじは不要。**引き抜きロックはありません**。本体を前に傾けないこと。

## 印刷
Flashforge Adventurer 5M, 0.4mmノズル PETG, 層0.20mm, 外周4壁、235〜245℃、ベッド75〜85℃（製品指定を優先）。
各STLは220×220×220mm範囲・閉じたメッシュを機械的に確認。中央プレートと左右トレーは造形方向によってサポートが必要です。**スライサーで接続レール・天板の浮き部分にサポートがあるか必ずチェック**してください。
ドリンクホルダーはリングを下にした向きで、支柱やハンガー下面にサポートが必要になる場合があります。

## 使用制限／注意
- **スマホ・テンキーを置く前に、机上で手で組み立ててぐらつきを確認**してください。
- 左右スライドとカップハンガーには独立ロックがありません。持ち運び時や三脚の傾斜で抜けることがあります。ネジなし固定の利便性とのトレードオフです。
- 飲料は特に危険です。荷重テスト・転倒安全の実証は行っていません。**液体や重い容器を入れて使用しないでください**。まず空の容器だけで形状確認する試作品として扱ってください。
- 以前確認済みの70mmプレートそのものは、中央トレーとの一体化で重量が増すため、取り付け全体の安全性は未検証です。
- 印刷済みの保持部が96×65mmの実寸と大きく異なる場合、そのままでは嵌合しない可能性があります。
''' 
(P/'README_印刷順と注意.md').write_text(readme,encoding='utf-8')
(P/'generate_v07.py').write_text(Path(__file__).read_text(),encoding='utf-8')
Z=Path('/mnt/data/ArrowsAlpha_LiveTray_v07_no_screws_final_TEST_DESIGN.zip')
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED) as z:
 for f in P.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(P))
print('SUCCESS',Z,Z.stat().st_size)
