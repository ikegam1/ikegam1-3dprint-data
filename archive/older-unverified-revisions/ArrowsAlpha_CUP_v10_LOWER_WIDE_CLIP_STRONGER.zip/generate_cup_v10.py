"""v1.0 drop-cup holder: wide deck saddle, load-bearing fan/gussets, cup 30mm lower.
Fits ArrowsAlpha_LiveTray_v09 center STEP, screwless, printable on AD5M. All mm.
"""
from pathlib import Path
import json, zipfile, shutil, math
import cadquery as cq
from cadquery import exporters
import trimesh, numpy as np
from matplotlib import pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon
ROOT=Path('/mnt/data/ArrowsAlpha_LiveTray_v10_LOW_CUP_WIDE_SADDLE')
STL=ROOT/'01_STL_PRINT'; STEP=ROOT/'02_EDITABLE_STEP'; IMG=ROOT/'03_DIMENSIONED_DRAWINGS'
for d in (ROOT,STL,STEP,IMG):d.mkdir(parents=True,exist_ok=True)
CENTER=cq.importers.importStep('/mnt/data/01_CENTER_V09_70mm_GRIP_110x114_PHONE_DOCK.step').val()
OLD=cq.importers.importStep('/mnt/data/03_CUP_V09_SHAPE_UNCHANGED_EMPTY_ONLY.step').val()

def box(w,d,h,x=0,y=0,z=0):return cq.Workplane('XY').box(w,d,h).translate((x,y,z)).val()
def cyl(r,h,x=0,y=0,z=0):return cq.Workplane('XY').circle(r).extrude(h).translate((x,y,z)).val()
def xz_poly(points,y0,depth):
 # Normal of XZ plane points -Y, extrudes from y0 toward negative Y
 return cq.Workplane('XZ',origin=(0,y0,0)).polyline(points).close().extrude(depth).val()
def yz_poly(points,x0,width):
 # YZ plane normal +X, extrudes +X
 return cq.Workplane('YZ',origin=(x0,0,0)).polyline(points).close().extrude(width).val()

# Exterior cup holder for ~80-mm class drink vessel; full ring and perforated strong floor.
R=46.0; r=41.5; CY=-112.0; zbase=-107.0; zrim=-35.0
cup=cyl(R,zrim-zbase,0,CY,zbase).cut(cyl(r,zrim-zbase+1.0,0,CY,zbase-0.25))
# Load-bearing 3 x 3 integrated base grate, laid DIRECTLY on the print bed (no hanging bridge).
# Every bar touches/overlaps the cup wall by 0.7 mm so the bottom cannot peel away.
mesh=None
for offset in (-19,0,19):
 for s in [box(7.5,90,4,offset,CY,zbase+2),box(90,7.5,4,0,CY+offset,zbase+2)]:
  mesh=s if mesh is None else mesh.fuse(s)
mesh=mesh.intersect(cyl(r+0.8,4,0,CY,zbase))
cup=cup.fuse(mesh).clean()

# Ventilated lower shell, but keep rear semicircle intact where supporting webs enter.
# Pointed upper ends avoid flat 20-mm horizontal bridges over the windows.
for theta in [-160,-125,-90,-55,-20]:
    win = (cq.Workplane('YZ').polyline([(-10,-93),(10,-93),(10,-69),(0,-59),(-10,-69)]).close().extrude(14).translate((36,0,0)).val()
         .rotate((0,0,0),(0,0,1),theta).translate(cq.Vector(0,CY,0)))
    cup=cup.cut(win)

# Two strong, tapered wings: bottom roots overlap cup circumference, tops widen into saddle.
for sign in (-1,1):
 # XZ polygons from +-23..37 at lower end to +-19..55 at deck end.
 points=[(sign*23,-51),(sign*38,-51),(sign*56,11.5),(sign*19,11.5)]
 if sign==-1:points.reverse()
 fin=xz_poly(points,-78,13.0)   # Y -91 .. -78; overlaps at the circular wall
 cup=cup.fuse(fin)
 # gusset running radially between rear circumference and upright fin
 # Thick triangular gusset: y=-104 at base z=-50, up to y=-79 z=-19.
 rib=yz_poly([(-94,-59),(-75,-59),(-77,-19),(-88,-19)],sign*29-5,10)
 cup=cup.fuse(rib)

# Center web starts at rounded cup wall and slopes rearward to broad clip at deck.
mid=yz_poly([(-71.5,-54),(-62.5,-54),(-79.5,10),(-94,10)],-11,22)
cup=cup.fuse(mid)
# Broad transverse load-bearing beam right below clamp throat.
# Keeps wings connected, distributes forces to >=100mm contact.
beam=box(113,12.0,9.0,0,-88.0,10.0)  # y -94..-82, z5.5..14.5
cup=cup.fuse(beam)

# Deck saddle: v0.9 deck z=9..15, front edge y=-81; dock phone front-stop starts y=-55.7.
# Occupies y=-94..-59, max width 114mm; no screw and no separate pins.
# Solid throat never touches center's frontal edge (0.4mm relief).
# Top shelf at z>=15.3; bottom shelf <=8.7, deck gap =6.6 mm.
TOP=box(113,34,4.2,0,-77.5,17.40)   # y -94.5 .. -60.5, z15.30..19.50
BOTTOM=box(113,34,4.0,0,-77.5,6.70) # y -94.5..-60.5, z4.70..8.70
THROAT=box(113,12,10.9,0,-88.0,10.35)  # y -94..-82 ; z4.90..15.80
# For deck y>=-81, throat does not overlap 0.9mm.
cup=cup.fuse(TOP).fuse(BOTTOM).fuse(THROAT)
# Heavy under-shelf wedge rather than unsupported cantilever.
# YZ wedge under bottom shelf from y=-92 z=-16 to y=-60 z=4.55.
# Floor wedge is isolated from deck slot; it supports cap during print.
for x0,width in [(-51,13),(-10,20),(38,13)]:
 wedge=yz_poly([(-85,-22),(-76,-22),(-60.5,4.70),(-96,4.70)],x0,width)
 cup=cup.fuse(wedge)
# Clearance for inserted central deck: 0.45mm above/below its top/bottom; remove protrusions from braces only.
# y >= -81, between z8.7 and 15.3 must stay EMPTY for the 6-mm deck.
deck_space=box(137,90,6.60,0,-36,12.0)  # y -81..9, z8.70..15.30
cup=cup.cut(deck_space).clean()
# Gentle rounded/chamfered exterior lip optional; keep one solid not brittle.

# Print upright on full annular, perforated bottom: the strongest cup-to-brace orientation.
# Move bottom z to 0, center XY on bed; printable max z ~127 mm.
bb=cup.BoundingBox()
printshape=cup.translate(cq.Vector(110-(bb.xmin+bb.xmax)/2,110-(bb.ymin+bb.ymax)/2,-bb.zmin))
FN='CUP_V10_LOWER_30mm_WIDE_113mm_SADDLE_ID83mm'
exporters.export(cup,str(STEP/(FN+'.step')),exportType='STEP')
exporters.export(printshape,str(STL/(FN+'_AD5M_PRINT_UPRIGHT.stl')),exportType='STL',tolerance=.05,angularTolerance=.18)
m=trimesh.load(str(STL/(FN+'_AD5M_PRINT_UPRIGHT.stl')),force='mesh')
assert m.is_watertight, 'not watertight'
assert len(m.split())==1, 'disconnected mesh'
assert np.all(m.extents <= 220.0),'oversized for AD5M'
assert abs(m.bounds[0][2])<0.01,'not on bed'
# Compare CAD solid old, revised, center
volsum= cup.intersect(CENTER).Volume()
print('CENTER intersection volume',volsum)
assert volsum<0.05, 'central tray COLLISION'
# Insertion: clip slides from front y < -81.0 until its top/bottom shelf covers 20.5 mm;
# test 1mm increments. At more forward than final is collision-free geometrically.
slide=[]
for delta in np.linspace(-55,0,56):
 q=cup.translate(cq.Vector(0,float(delta),0))
 v=q.intersect(CENTER).Volume()
 slide.append(round(float(v),6))
 if v>0.05:raise RuntimeError(f'slide intersects at {delta}: {v}')
print('slide verified',max(slide))
# Actual plate front of central at y -81; total overlap top shelf y[-81,-60.5] ~20.5 mm.
# Additional combined sanity: should not touch printed phone holder base y[-51,63].
print('v10 bounding:',bb.xmin,bb.xmax,bb.ymin,bb.ymax,bb.zmin,bb.zmax)
print('mesh:',m.extents,'volume:',m.volume,'watertight',m.is_watertight,'components',len(m.split()))

# Draw engineering diagram of attachment cross-section and lowered cup.
plt.rcParams['font.family']='DejaVu Sans'
fig,ax=plt.subplots(figsize=(12,7.6))
# Side view Y vs Z (projected), retain true model coordinates.
ax.add_patch(Rectangle((-81,9),162,6,facecolor='#bfc5ca',edgecolor='#555d64',lw=1.6))
ax.add_patch(Rectangle((-94.5,15.30),34,4.2,facecolor='#cc6557',edgecolor='#772c2c',alpha=.9))
ax.add_patch(Rectangle((-94.5,4.70),34,4,facecolor='#cc6557',edgecolor='#772c2c',alpha=.9))
ax.add_patch(Rectangle((-94,-0),12,18.5,facecolor='#bb5c52',edgecolor='#772c2c'))
ax.add_patch(Rectangle((CY-R,zbase),R*2,zrim-zbase,facecolor='#d8837b',edgecolor='#922d2a',lw=2,alpha=.7))
ax.add_patch(Rectangle((CY-r,zbase+3.8),r*2,zrim-(zbase+3.8),facecolor='white',edgecolor='#922d2a',lw=1))
ax.add_patch(Polygon([(-95,10),(-78,10),(-73,-54),(-78,-54)],closed=True,fc='#9d514b',alpha=.9))
ax.plot([-210,-25],[15,15],lw=.6,color='#999')
ax.annotate('Broad saddle: 113 mm wide, 20.5 mm plate contact',xy=(-70,17.6),xytext=(-55,68),arrowprops={'arrowstyle':'->'},fontsize=10)
ax.annotate('Reinforced 3-web support',xy=(-86,-22),xytext=(-45,-40),arrowprops={'arrowstyle':'->'},fontsize=10)
ax.annotate('Cup rim: 30 mm LOWER',xy=(-144,-35),xytext=(-200,42),arrowprops={'arrowstyle':'->'},fontsize=11)
ax.annotate('Cup inner Ø83 mm',xy=(-120,-100),xytext=(-200,-130),arrowprops={'arrowstyle':'->'},fontsize=11)
ax.set_aspect('equal');ax.set_xlim(-230,78);ax.set_ylim(-144,79);ax.axis('off')
ax.set_title('v1.0 cup redesign | side elevation | section concept (mm)',fontsize=16)
fig.savefig(IMG/'01_CUP_LOWER_SIDE_SECTION.png',dpi=175,bbox_inches='tight');plt.close(fig)

# Top view: full contact width
fig,ax=plt.subplots(figsize=(10,6))
ax.add_patch(Rectangle((-68,-81),136,162,facecolor='#dfe7ea',edgecolor='#54666d',lw=2))
ax.add_patch(Rectangle((-56.5,-94.5),113,34,facecolor='#cf8277',edgecolor='#993629',lw=2))
ax.add_patch(Circle((0,CY),R,facecolor='#df998e',edgecolor='#993629',lw=2))
ax.add_patch(Circle((0,CY),r,facecolor='white',edgecolor='#993629',lw=1.5))
ax.add_patch(Rectangle((-55,-51),110,114,fill=False,edgecolor='#2676a2',lw=1.3))
ax.plot([-56.5,56.5],[-94.5,-94.5],color='#993629',lw=1)
ax.annotate('113-mm WIDE SADDLE',xy=(45,-72),xytext=(75,-108),arrowprops={'arrowstyle':'->'},fontsize=11)
ax.annotate('Cup axis shifted 6 mm nearer the tripod',xy=(0,CY),xytext=(-150,-177),arrowprops={'arrowstyle':'->'},fontsize=10)
ax.set_aspect('equal');ax.set_xlim(-185,185);ax.set_ylim(-200,100);ax.axis('off');ax.set_title('v1.0 cup | top view | mounts on v0.9 center tray front edge')
fig.savefig(IMG/'02_TOP_VIEW_SADDLE.png',dpi=165,bbox_inches='tight');plt.close(fig)

record={'version':'v1.0','references':'ArrowsAlpha_LiveTray_v09 center tray',
'clip_plate_width_mm':113.,'clip_plate_slide_depth_mm':20.5,'center_deck_nominal_thickness_mm':6.,
'clip_gap_mm':6.6,'clip_upper_lip_bottom_mm':15.30,'clip_lower_lip_top_mm':8.70,
'new_cup_outer_diameter_mm':92.,'new_cup_inner_diameter_mm':83.,'new_cup_rim_z_mm':zrim,
'old_cup_rim_z_approx_mm':-5.,'new_rim_drop_mm':30.,'new_cup_bottom_z_mm':zbase,
'assembled_center_slide_collision_mm3':round(float(volsum),7),
'assembly_slide_checks':len(slide),'max_slide_collision_mm3':max(slide),
'print_size_xyz_mm':[round(float(v),2) for v in m.extents],
'one_component':len(m.split())==1,'watertight':bool(m.is_watertight),'mesh_volume_mm3':round(float(m.volume),2),
'estimated_PETG_part_weight_g':round(float(m.volume*1.27/1000),1),
'caveats':['Built for v0.9 central tray 136x162, front edge at y=-81, z9..15. Other designs may not fit.',
'Printed fit, friction and loaded strength not verified physically.',
'Printed cup alone is not certified to safely carry a filled drink; check stability and cup diameter with empty container.',
'Upper saddle tongue is partly overhanging and may require slicer support; remove support from structural areas with care.',
'No positive rearward sliding lock exists: lift/tilt can cause disengagement.']}
(ROOT/'verification.json').write_text(json.dumps(record,indent=2,ensure_ascii=False),encoding='utf-8')
readme=f'''# 配信用トレー用 ドリンクホルダー v1.0：低重心・幅広サドル・補強設計

**印刷するものはSTL 1個だけです。追加のネジ・ナット・独立ジョイントはありません。**

## 前回の問題を修正
- 旧版：カップを吊るす細い2本の柱に負担が集中。サポートを外すと折れる危険な構造でした。
- 新版：**幅113mmの一体サドル**が中央テーブルの前縁を上下から抱え込み、上下面で荷重を分散します。実際にスライドして接触する奥行は約20.5mm。
- カップと受け部の間は、**中央ウェブ＋左右テーパー状の幅広リブ計3本**。カップ壁に直接一体化しています。
- カップの縁は前版より**30mm低い**位置。カップ中心は旧版（およそ y=-118mm）より**6mm中央寄り（y=-112mm）**。
- **内径83mm／外径92mm**。コップ底・側面を覆う構造で、底は壁と一体の3×3格子（グリッド）です。
- 取付方式：**v0.9中央トレーの前縁に前方から差し込み**。同じ部材同士はCAD干渉検査済み。ほかの世代とは互換性未検証。

## 3Dプリント手順（AD5M／PETG／0.4mm）
- `{FN}_AD5M_PRINT_UPRIGHT.stl` を1個印刷。
- カップの底が下になる**縦置き**の向きでSTLを出力済み（高さ約127mm）。スライサーで勝手に寝かせないでください。
- PETG 235-245°C／ベッド75-85°C、積層0.20mm、外周4-5周、インフィル20-30%、ブリム4-6mmが初期値。
- **注意：上部の取り付けサドルは一部が張り出すため、部分サポートが必要になることがあります。** スライサープレビューでサドルの上側フランジ直下を確認し、必要ならサポートを最小限にして、支柱本体・カップ縁にサポートが密着しないよう設定してください。
- サポート除去ではフランジを引っ張らず、ニッパーで少しずつ切り離してください。以前の壊れた細い吊り柱は廃止しました。

## 取付前の確認
1. 中央トレーが**v0.9の印刷データ**であること。前縁の厚みが設計値6mmであること。
2. 中央トレーが三脚にしっかり保持された状態で、空のカップホルダーを前縁に軽く差し込む。無理な力で押し込まないでください。
3. 空の容器を使ってガタと接触の形状を確認。内径83mmに入らないボトル・太いタンブラーは載せないでください。
4. 両側テーブル・スマホを付けて三脚が傾かないか検証。**満杯のドリンクはまだ使用しないでください。**

## 安全・設計上の限界
- v0.9中央トレー（前縁 y=-81mm、天面 z15mm、裏面 z9mm）とのCAD干渉検査は合格。実機における摩擦・差し込み力・耐荷重・転倒安全性は未検証です。
- このアタッチメントには積極的な抜け止めラッチはありません。三脚を傾けたり持ち運んだりすると抜ける可能性があります。飲料を使う前に物理保持試験が必要です。
- 別売りのネジやジョイントを増やす設計にはしていません。
- 補強によって前版よりフィラメント使用量が増える可能性があります。
'''
(ROOT/'README_印刷と互換性.md').write_text(readme,encoding='utf-8')
shutil.copy(__file__, ROOT/'generate_cup_v10.py')
zipfile_path=Path('/mnt/data/ArrowsAlpha_CUP_v10_LOWER_WIDE_CLIP_STRONGER.zip')
with zipfile.ZipFile(zipfile_path,'w',zipfile.ZIP_DEFLATED) as z:
 for f in ROOT.rglob('*'):
  if f.is_file(): z.write(f,str(f.relative_to(ROOT)))
print('SUCCESS',zipfile_path,zipfile_path.stat().st_size)
