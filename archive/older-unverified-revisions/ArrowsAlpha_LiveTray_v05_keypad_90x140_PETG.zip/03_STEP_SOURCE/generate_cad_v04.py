"""Arrows Alpha livestream shelf, AD5M 220^3 PETG modular concept CAD.
CAUTION: Prototype; mechanical load testing and clamp fit are required before use.
"""
from pathlib import Path
import os, math, json, zipfile, shutil
import cadquery as cq
from cadquery import exporters
import trimesh
from matplotlib import pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch, Polygon

R=Path('/mnt/data/ArrowsAlpha_LiveTray_v04_phone_backwall_PETG')
D=R/'01_STL_PRINT_PARTS'; TEST=R/'02_PRINT_TEST_FIRST'; SRC=R/'03_STEP_SOURCE'; VIZ=R/'04_DRAWINGS'
for p in [D,TEST,SRC,VIZ]:p.mkdir(parents=True,exist_ok=True)
# Geometry in mm. TOP of shelf floor +6.4; underside 0, clamp base is a separate item.
SIDE_X=55.; EXTREME_X=170.; YMAX=57.; FLOOR=6.4
CLAMP_WIDTH=70.; CLAMP_DEPTH=52.; CLAMP_THICK=9.0
PHONE_WIDTH=72.; PHONE_HEIGHT=156.; PHONE_THICK=8.8; GUIDE_HEIGHT=65.
BOLT_DIAM=4.4
all_validation=[]

def box(a,b,c,x=0,y=0,z=0):
 return cq.Workplane('XY').box(a,b,c).translate((x,y,z)).val()

def cut_hole(sh,x,y,z0,z1,r=2.2):
 h=cq.Solid.makeCylinder(r,z1-z0,cq.Vector(x,y,z0),cq.Vector(0,0,1))
 return sh.cut(h)

def chamfer_vertical(s,amount):
 try:return cq.Workplane(obj=s).edges('|Z').fillet(amount).val()
 except Exception as e:print('fillet skip',e);return s

def extrude_yz(points,xstart,width):
 return cq.Workplane('YZ',origin=(xstart,0,0)).polyline(points).close().extrude(width).val()

def validate_export(part,path,plate=True):
 exporters.export(part,str(path),exportType='STL',tolerance=.09,angularTolerance=.24)
 m=trimesh.load(str(path),force='mesh',process=True)
 sz=[round(float(v),2) for v in m.extents]
 if not m.is_watertight or m.volume<1:raise RuntimeError('non watertight '+path.name+' '+str(m.is_watertight))
 if plate and any(v>220.001 for v in m.extents):raise RuntimeError('bed fit '+str(sz)+' '+path.name)
 if plate and any(v<-0.01 for v in m.bounds[0]):raise RuntimeError('bed below0 '+str(m.bounds)+' '+path.name)
 all_validation.append({'name':path.name,'size_xyz_mm':sz,'closed':m.is_watertight,'volume_mm3':round(float(m.volume),1),'fits_220mm_cube':all(v<=220.01 for v in m.extents),'bounds':[list(map(lambda t:round(float(t),2),m.bounds[0])),list(map(lambda t:round(float(t),2),m.bounds[1]))]})
 print(path.name,sz,'vol',round(m.volume),'watertight',m.is_watertight)
 return m

def shift_print(s):
 bb=s.BoundingBox()
 return s.translate((110-(bb.xmin+bb.xmax)/2,110-(bb.ymin+bb.ymax)/2,-bb.zmin))

# Test / production clamp blade: central underside plate gripped by the spring-loaded SELECOCO jaws
# 70mm across X (fixed jaw inside min65mm), 52mm deep front/back. 9mm thick.
# Four M4 clearance holes and underside nut pockets leave outer gripping surfaces unchanged.
def clamp_blade(width):
 s=box(width,CLAMP_DEPTH,CLAMP_THICK,0,0,CLAMP_THICK/2)
 s=chamfer_vertical(s,1.3)
 for x in (-23,23):
  for y in (-16,16):
   s=cut_hole(s,x,y,-1,CLAMP_THICK+1)
   # Captive M4 hex nut 7mm across flats => circumradius 4.2mm. Pocket open from below.
   pocket=cq.Workplane('XY').polygon(6,8.3).extrude(3.5).translate((x,y,-.01)).val()
   s=s.cut(pocket)
 return s.clean()

clamp=clamp_blade(70.)
def clamp_print_orientation(s):
 # Print the wide solid upper surface on bed; nut pockets are upwards when printed.
 # Installed plate is flipped again so pockets face downwards with captured M4 nuts.
 s=s.rotate((0,0,0),(1,0,0),180)
 return shift_print(s)
validate_export(clamp_print_orientation(clamp),D/'AD5M_01_70mm_TRIPOD_CLAMP_PLATE.stl')
exporters.export(clamp,str(SRC/'TRIPOD_CLAMP_PLATE_70mm.step'),exportType='STEP')
for w in (68,70,72):
 validate_export(clamp_print_orientation(clamp_blade(w)),TEST/f'TEST_CLAMP_ONLY_{w}mm_SELECT_ONE.stl')

# Tray central piece: solid 110x114x6.4 mm, and two leaning 130 mm high side guide towers.
center=box(110,114,FLOOR,0,0,FLOOR/2)
center=chamfer_vertical(center,2.0)
# four vertical fastener clearance holes for removable clamp blade,
# fastener heads countersunk into the tray so a phone can still stand on the floor.
for x in (-23,23):
 for y in (-16,16):
  center=cut_hole(center,x,y,-.1,FLOOR+.1)
  center=cut_hole(center,x,y,FLOOR-1.6,FLOOR+0.1,r=3.65)
# Joiner fastener holes shared with side tray connector bars
for x in (-35,35):
 for y in (-36,36):
  center=cut_hole(center,x,y,-.1,FLOOR+.1)
# Cup holder two bolt holes y near front (will be buried below mouth area but accessible above)
for x in (-22,22):center=cut_hole(center,x,-38,-.1,FLOOR+.1)
# v03 phone slot: narrow channel, short front/back depth, matching L-shaped front/rear returns.
# Outer side rails are 6mm thick; INNER x-distance=72.6mm. Actual smartphone + case must be checked.
# Front and rear return tabs lightly wrap around SIDE BEZEL (not active screen).
# Back center deliberately open for card sleeve; side-edge contacts only.
PHONE_SLOT_W=72.6
PHONE_SLOT_D=18.0
GUIDE_X=PHONE_SLOT_W/2
GUIDE_W=6.0
GUIDE_Y=3.0
RAIL_Z0=FLOOR
RECESS=1.5
# Shallow bottom locating recess; 15mm depth rather than former 21.5mm.
center=center.cut(box(PHONE_SLOT_W,PHONE_SLOT_D,RECESS,0,GUIDE_Y,FLOOR-RECESS/2))
for side in (-1,1):
 rail=center if False else box(GUIDE_W,PHONE_SLOT_D+2.0,GUIDE_HEIGHT,side*(GUIDE_X+GUIDE_W/2),GUIDE_Y,RAIL_Z0+GUIDE_HEIGHT/2)
 center=center.fuse(rail)
 # Equal symmetric corner hooks at FRONT and REAR, along full guide height.
 # A 1.1mm inward overlap of the edge only; rounded finish by post print deburr.
 for face in (-1,1):
  tab=box(1.1,3.4,GUIDE_HEIGHT-2,side*(GUIDE_X-0.55),GUIDE_Y+face*(PHONE_SLOT_D/2-1.2),RAIL_Z0+(GUIDE_HEIGHT+2)/2)
  center=center.fuse(tab)
# Add stiff low back wall across most of phone rear. Its 34-mm height is roughly half
# the 65-mm side guide; it sits behind the card holder's likely footprint and
# deliberately leaves the upper camera area completely open.
# The wall is at the REAR of slot (positive Y) and front lip faces negative Y.
BACK_WALL_H=34.0
BACK_WALL_T=3.0
rear_y=GUIDE_Y + PHONE_SLOT_D/2 + 1.0
backwall=box(PHONE_SLOT_W+2*GUIDE_W, BACK_WALL_T, BACK_WALL_H,
             0, rear_y, FLOOR+BACK_WALL_H/2)
center=center.fuse(backwall).clean()
validate_export(shift_print(center),D/'AD5M_02_CENTRAL_TRAY_SYMMETRIC_65mm.stl')
exporters.export(center,str(SRC/'CENTRAL_TRAY_PHONE_GUIDES.step'),exportType='STEP')

# Side trays: two mirrored 115mm wide x 114mm deep shallow trays, front/back/outer edge walls; no edge at seam.
# Add 2 rectangular stiffeners under each wing as short ribs parallel X (but don't block screw holes near seam)
side_parts=[]
for side,tag in [(1,'RIGHT'),(-1,'LEFT')]:
 s=box(115.,114.,FLOOR,side*112.5,0,FLOOR/2)
 s=chamfer_vertical(s,3.0)
 # tray walls: z from floor to 15.4, wall about 3mm, leave seam edge open
 for y in (-55,55):s=s.fuse(box(115,4,8,side*112.5,y,FLOOR+4))
 s=s.fuse(box(4,114,8,side*168.,0,FLOOR+4))
 # underside strips behind and ahead of screws avoiding touching bed issue: ribs would force large floor bridging if printed as one!
 # Thus omit underside ribs and use add-on bridge bars secured by M4 screws.
 for x in (side*75,):
  for y in (-36,36): s=cut_hole(s,x,y,-.1,FLOOR+.1)
 s=s.clean()
 side_parts.append((tag,s,side))
 validate_export(shift_print(s),D/f'AD5M_03_{tag}_TRAY.stl')
 exporters.export(s,str(SRC/f'{tag}_TRAY.step'),exportType='STEP')

# Seam reinforcement; 4 detachable bars, each spans seam with 2 M4 screws.
# Width 61mm x 18mm; bolts 40mm apart, material 10mm beyond each screw.
# Bars install BELOW floor using exposed cap screws from above and M4 nuts below.
for side,tag in [(1,'RIGHT'),(-1,'LEFT')]:
 for y,t in [(-36,'FRONT'),(36,'REAR')]:
  bar=box(62,18,4,side*55,y,2)
  bar=chamfer_vertical(bar,2.1)
  for x in (side*35,side*75):bar=cut_hole(bar,x,y,-1,5)
  validate_export(shift_print(bar),D/f'AD5M_04_JOIN_BAR_{tag}_{t}.stl')

# CUP/BASKET dimensions. Mounted cup ring center at y=-105, top z=-26. Inside diameter 82.
# cup basket is its own detachable STL. A rear riser and horizontal ledge screw into underside tray.
# Print ON FLOOR at basket bottom then place in assembly by z shift=-99 and y shift=-105.
# Rim top 73 mm -> -26. Ledge z 93..99 -> -6..0.
# Tubular basket rings and vertical staves leave open wall to keep light.
CUP_ORT=105.; CUP_LOCAL_TOP=73.; CUP_R_OUT=45.5; CUP_R_IN=40.6
bottom=cq.Workplane('XY').circle(CUP_R_OUT).circle(CUP_R_IN).extrude(5).val()
# bottom cross supports; no solid closed disk: drainage and low mass
bottom=bottom.fuse(box(83,7,5,0,0,2.5)).fuse(box(7,83,5,0,0,2.5))
upper=cq.Workplane('XY').circle(CUP_R_OUT).circle(CUP_R_IN).extrude(11).translate((0,0,62)).val()
basket=bottom.fuse(upper)
# 8 mostly-vertical rib staves between upper and lower ring
for i in range(8):
 a=2*math.pi*i/8
 rib=box(6,7,58,CUP_R_OUT-2.8,0,33)
 rib=rib.rotate((0,0,0),(0,0,1),a*180/math.pi)
 basket=basket.fuse(rib)
# Rear vertical bracket pillars and leaning braces, support ledge at z93..99
for x in (-22,22):
 # sloped upright prism y rear 34->~66, rising from basket upper to shelf underside
 # this is printable only WITH SUPPORT for the ledge from the plate; separate supportive gussets reduce unsupported bridges
 upright=extrude_yz([(34,60),(44,60),(75,93),(63,93)],x-5,10)
 basket=basket.fuse(upright)
# Broad ledge connects both pillars at z93..99 spanning y from 64 to 84
ledge=box(66,28,6,0,70,96)
basket=basket.fuse(ledge)
# Back stabilizer flanges, triangle webs from basket to upper plate; avoid support for long cantilever as far as possible
for x in (-23,23):
 gusset=extrude_yz([(41,58),(46,72),(84,93),(64,93)],x-4,8)
 basket=basket.fuse(gusset)
# Hole locations assembled y=-38 -> cup local y=67; two bolts x±22.
for x in (-22,22):basket=cut_hole(basket,x,67,92.9,100.5)
basket=basket.clean()
validate_export(shift_print(basket),D/'AD5M_05_FRONT_CENTER_LOWER_CUP_BASKET_SUPPORTS_REQUIRED.stl')
exporters.export(basket,str(SRC/'FRONT_CENTER_CUP_BASKET.step'),exportType='STEP')

# Test phone groove slice from center, a real slice 22mm high, includes both side rails and base.
phone_test=center.intersect(box(96,65,25,0,3,12.5)).clean()
validate_export(shift_print(phone_test),TEST/'TEST_PHONE_SLOT_v04_BACKWALL_25mm_SHORT.stl')

# Complete CAD assembly as reference (too large to print as one piece: 340 mm wide).
assembly_parts=[center] + [s for name,s,side in side_parts] + [clamp.translate(cq.Vector(0,0,-9))] + [basket.translate(cq.Vector(0,-105,-99))]
for side in (-1,1):
 for y in (-36,36):
  joinbar=box(62,18,4,side*55,y,-2)
  for x in (side*35,side*75): joinbar=cut_hole(joinbar,x,y,-4.1,0.1)
  assembly_parts.append(joinbar)
assembly_comp=cq.Compound.makeCompound(assembly_parts)
exporters.export(assembly_comp,str(SRC/'ASSEMBLY_REFERENCE_NOT_FOR_PRINTING.step'),exportType='STEP')

# CAD meta and report
meta={'name':'Tripod mounted livestream tray for arrows alpha','version':'0.4 - symmetric side guides with rear support wall',
'printer':'Flashforge Adventurer 5M','material':'PETG','units':'mm',
'tray_outside_width':340,'tray_depth':114,'tray_floor_thickness':6.4,'tray_outer_lip_height':15,
'right_left_tray_width':115,'center_module_width':110,
'phone_height_nominal':156,'phone_width_nominal':72,'phone_thickness_nominal':8.8,
'phone_groove_width':72.6,'phone_side_rails_inner_width':72.6,'phone_rails_height_from_shelf':65,'rear_wall_height_mm':34,
'phone_lean_angle_deg_approx':0,
'card_holder_depth':'UNKNOWN; added 34mm high rear cross-wall; internal front/back 18mm; fit must be tested with actual sleeve',
'clamp_plate_width':70,'clamp_plate_depth':52,'clamp_plate_thickness':9,
'cup_inner_diameter':81.2,'cup_upper_edge_below_floor_mm':26,
'cup_max_extension_in_front_from_shelf_edge_mm':105+45.5-57,
'screws':{'center_clamp_plate':'four M4 x 20mm (check actual head/washer & nut height)','left_right_seams':'eight M4 x 16mm (4 per side)','cup':'two M4 x 16mm'},
'cautions':['Trial STL files require physical fit checks; do not assume secure mount or sufficient holding strength','Do not use with a filled drink until a controlled ballast/tilt load test passes','Large cantilever plus drink is dangerous; a strap or additional tether to tripod is strongly recommended','Phone card sleeve total depth is unmeasured','Bed fitting and mesh closure does not prove structural strength','Cup part requires supports, especially the upper mounting ledge'],
'files':[d['name'] for d in all_validation]}
(SRC/'design_dimensions_and_warnings.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
(SRC/'stl_validation.json').write_text(json.dumps(all_validation,ensure_ascii=False,indent=2),encoding='utf8')
shutil.copy(__file__,SRC/'generate_cad_v04.py')

# Draw engineering 2D top and front layout with measured dimensions; text Japanese works via Noto CJK if installed.
import matplotlib
matplotlib.rcParams['font.family']='DejaVu Sans'
fig,axs=plt.subplots(2,1,figsize=(13,11),gridspec_kw={'height_ratios':[1.5,1]})
ax=axs[0]
for x,w,t in [(-112.5,115,'LEFT'),(0,110,'CENTER'),(112.5,115,'RIGHT')]:
 ax.add_patch(Rectangle((x-w/2,-57),w,114,fc='#dbe7ed' if t=='CENTER' else '#e4e8ea',edgecolor='#242d31',lw=2))
 if t!='CENTER':
  ax.add_patch(Rectangle((x-w/2+8,-49),w-16,98,fill=False,edgecolor='#607d89',lw=2))
  ax.text(x,5,'NUMPAD' if x>0 else 'FREE AREA',ha='center',va='center',size=12)
for x in (-55,55):ax.plot([x,x],[-57,57],'--',color='red',linewidth=2)
ax.add_patch(Rectangle((-36.3,-4.5),72.6,15,fill=False,edgecolor='#154e7d',lw=3))
ax.text(0,36,'PHONE SLOT 72.6 mm / BACK WALL 34 mm',ha='center',fontsize=11)
for x in (-23,23):
 for y in (-16,16):ax.plot(x,y,'k.',ms=5)
for x in (-35,35,75,-75):
 for y in (-36,36):ax.plot(x,y,'ko',ms=4)
for x in (-55,55):
 for y in (-36,36):ax.add_patch(Rectangle((x-31,y-9),62,18,fill=False,edgecolor='#be7b24',lw=2))
# cup circles at y=-105
ax.add_patch(Circle((0,-105),45.5,fc='#e7e5dc',ec='#915620',lw=3));ax.add_patch(Circle((0,-105),40.6,fc='white',ec='#915620',lw=2))
ax.text(0,-104,'CUP\nø81.2 inside',ha='center',va='center',fontsize=12)
ax.text(-170,-155,'4 join bars underneath / 70-mm clamp plate under central module',fontsize=10)
ax.set_xlim(-194,194);ax.set_ylim(-165,80);ax.set_aspect('equal');ax.axis('off');ax.set_title('TOP VIEW — width 340 mm / depth 114 mm / central cup lowered',fontsize=16)
ax=axs[1]
ax.add_patch(Rectangle((-170,0),340,6.4,fc='#bdcbd4',ec='#3c4950'))
ax.add_patch(Rectangle((-170,6.4),115,9,fc='#bdcbd4',ec='#3c4950'))
ax.add_patch(Rectangle((55,6.4),115,9,fc='#bdcbd4',ec='#3c4950'))
ax.add_patch(Rectangle((-35,-9),70,9,fc='#87979d',ec='#2e3d45'))
for x in (-39.3,39.3):ax.add_patch(Rectangle((x-3,6.4),6,65,fc='#587c96',ec='#223642'))
ax.add_patch(Rectangle((-36,6.4),72,156,fc='#add3ea',ec='#405867',alpha=.7))
ax.plot([-35,35],[-28,-28],color='#b17f23',lw=4)
ax.add_patch(Rectangle((-45.5,-99),91,73,fc='#e3dacf',edgecolor='#925f24',lw=3,alpha=.5))
ax.text(61,84,'SYMMETRIC FRONT/REAR LIPS\n65 mm SIDE GUIDES / 34 mm BACK WALL',fontsize=11)
ax.text(62,-50,'CUP BELOW THE SCREEN\nLOWER THAN THE TRAY',fontsize=11)
ax.set_xlim(-185,185);ax.set_ylim(-110,182);ax.set_aspect('equal');ax.axis('off');ax.set_title('FRONT CONCEPT — 65 mm mirrored side retaining guides',fontsize=16)
fig.tight_layout();fig.savefig(VIZ/'01_DIMENSIONED_TOP_FRONT.png',dpi=155);plt.close(fig)

# Assembly sequence picture
fig,ax=plt.subplots(figsize=(11,6))
ax.add_patch(Rectangle((-55,-57),110,114,fc='#d8e5eb',ec='#24383e',lw=2))
ax.add_patch(Rectangle((-170,-57),115,114,fc='#e5e8ea',ec='#24383e',lw=2))
ax.add_patch(Rectangle((55,-57),115,114,fc='#e5e8ea',ec='#24383e',lw=2))
for x in (-55,55):
 for y in (-36,36):
  ax.add_patch(Rectangle((x-31,y-9),62,18,fc='#f0c56b',alpha=.6,ec='#825c1a'))
  for bx in (x-20,x+20):ax.plot(bx,y,'ko',ms=6)
ax.add_patch(Rectangle((-35,-26),70,52,fill=False,edgecolor='#185583',lw=4))
ax.add_patch(Circle((0,-105),45.5,fill=False,edgecolor='#8b581d',lw=4))
ax.text(-110,10,'LEFT',ha='center',weight='bold');ax.text(110,10,'RIGHT',ha='center',weight='bold');ax.text(0,40,'PHONE GUIDE',ha='center',weight='bold')
ax.annotate('70 mm clamp blade\nunder central floor',xy=(0,-20),xytext=(-92,-89),arrowprops=dict(arrowstyle='->',lw=2),fontsize=11)
ax.annotate('cup bracket: 2 x M4\nattached under center',xy=(0,-61),xytext=(75,-115),arrowprops=dict(arrowstyle='->',lw=2),fontsize=11)
ax.text(0,80,'ASSEMBLY: 3 tray parts + 4 seam bars + clamp blade + cup basket',ha='center',fontsize=14)
ax.set_xlim(-185,190);ax.set_ylim(-160,88);ax.set_aspect('equal');ax.axis('off')
fig.savefig(VIZ/'02_ASSEMBLY_LAYOUT.png',dpi=150,bbox_inches='tight');plt.close(fig)

readme='''# 配信用トレー v0.4 ― AD5M / PETG / arrows alpha / SELECOCOホルダー

**3D CAD試作**です。まだ実機の荷重試験も、スマホ・ホルダーの嵌合試験もできていません。三脚とドリンクを組み合わせるため、安全上 **先に小さい試験パーツを印刷**してください。

## 基本構成（寸法 mm）
- 左右トレーを含む全幅340 / 奥行114。左右各115mm・中央110mmの3ピース構成。
- 右はテンキー置き場、左も左右対称。側面と前後縁は落下防止壁（高さ約9mm）。
- 中央にスマホを「上から差すだけ」。本体公称 幅72 x 高さ156 x 厚み8.8mm。側面ガイド内幅72.6mm、高さ65mm。前後両側に同形状の約1.1mm内向きツメを付け、スマホの左右の縁のみ支えます。中央前面は開放。背面に高さ34mmの補強壁を追加しました。カメラのある背面上部は開放。前後の内側奥行は約18mmですが、カードホルダーが当たらないかテストが必要です。
- 三脚側既存SELECOCOホルダー **爪内65mm → 70mm幅の専用板を挟み込む**。三脚ネジは一切使いません。板の前後方向は52mm、厚さ9mm。現物の爪が開く範囲・奥行・摩擦力はテスト要。
- ドリンクホルダーは左右中心・手前・低い位置。上端がトレー下面より約26mm下、内径約81.2mm。液体の入った飲料の支持安全性は未検証です。

## 最初に印刷するもの
**最初の小テストは 02_PRINT_TEST_FIRST/TEST_CLAMP_ONLY_70mm_SELECT_ONE.stl の1個。** まず爪65mmの左右を広げた状態で挟んで、前後のずれ・回転・滑りを確認してください。強度・保持力が不足する場合は大型部品は印刷しないでください。
70mmがきつい・緩い場合は、同フォルダの68mmまたは72mmを試してください。
次に TEST_PHONE_SLOT_v04_BACKWALL_25mm_SHORT.stl で、厚みのある背面カードホルダーをつけた実際のスマホが差し込めるか確認してください。ガイド内側にクッションテープを貼る場合はその厚みも考慮してください。

## 本番部品（全9点）
- 01 70mm CLAMP_PLATE ×1：既存ホルダーの左右の爪で挟む**下面の70mm板**
- 02 CENTRAL_TRAY ×1：中央テーブル・65mm・前後対称の左右側面ガイド一体型
- 03 RIGHT_TRAY ×1、03 LEFT_TRAY ×1：左右テーブル
- 04 JOIN_BAR_{LEFT/RIGHT}_{FRONT/REAR} ×各1（計4本）：下面連結バー
- 05 FRONT_CENTER_LOWER_CUP_BASKET ×1：前下方ドリンクホルダー

## 締結部品（別途購入）
- M4ねじ **14本**、M4ナット14個（なるべくワッシャーも用意）。
- 使用箇所：中央底面⇔70mm固定プレート4本、左右トレー継手4×2＝8本、カップ部2本。
- ネジの長さは中央部M4×20、継手とカップM4×16が出発点。**ネジ頭とワッシャーの厚み、実際の穴の入り具合を確認して選定**してください。M4の首下長が短すぎても、長すぎても不適切です。
- 70mmプレートの裏にはM4ナット用六角ポケット付き。組立後の緩み止めも必要です。
- 滑り止め薄ゴムシート/クッションテープ、念のため落下防止のストラップを推奨します。

## 印刷方向 / スライス設定
- AD5Mの造形範囲220×220×220mm。各STLは**1パーツずつ**印刷してください。すべてのSTLの外形は220mm以下、保存時のビルドプレート座標内です。
- 中央：広いテーブル下面をビルドプレートへ、スマホ左右側面ガイドは上に直立。
- 左右トレー：底面を接地して、縁を上に向ける。
- 接続バー：平らな下面を下に。固定プレート：**STLでナット溝を上向きに配置済み**です。印刷後に裏返し、ナット溝が下側になる向きで中央本体に固定。三脚ホルダーに挟み込みます。
- カップ：リング底面をプレートへ。**取付アームの張り出しにサポート必須**。サポートがないと中空に落ちる可能性があります。スライスプレビューで張り出し下を確認。
- PETG、ノズル0.4mm、0.2mm積層、4壁、インフィル20～30%（接続部は高密度）を初期値としてください。取付板・接続バーは高めの充填率（40～60%）推奨。温度はフィラメント設定優先。
- 荷重がかかる部品の強度は素材の向き、レイヤー密着、印刷温度に依存。装置全体の荷重試験は未実施。

## 組立手順
1. 中央テーブルに左右トレーを突き合わせる。幅340mmになります。
2. 継ぎ目の下面4か所に細長い連結バーを当て、各2本のM4ボルトで固定。バーは本体の裏面に取り付けます。
3. 中央裏側に70mmの固定プレートを合わせ、4本のM4ネジで固定。元の三脚ホルダーを左右に広げ、この固定プレートの70mm幅を挟みます。**三脚のネジ穴は使いません**。
4. カップを中央前方の下面から当て、2本のM4で固定。重量物を入れる前に、接続部がたわまないか確認してください。
5. スマホは中央の溝に上から差し込むだけ。前面画面は全域が見える設計ですが、ケース/カードホルダーの形状次第で補正が必要です。

## 特に重要な注意
- 既存ホルダーは**65mmから開く**とのユーザー実測に基づく70mm設計ですが、摩擦力・バネの強さ・載せる重さは未知です。
- 340mm幅トレーはテコが効きます。テンキー操作や飲み物の荷重で傾く可能性があります。**実機で無荷重→ダミー重り→通常使用重量の順で検証**してください。
- お茶やコーヒーなどこぼれる飲料をいきなり置かないでください。特にスマホへの液体飛散と、三脚ごとの転倒に注意。
- クッション材は必ずスマホの側面とホルダー接触部に貼って、キズ・滑りを低減させてください。
- 取り付け板とスマホガイドの寸法は、実際のカードホルダー・ケースの厚みや三脚側接触面奥行に応じて再調整できます。開発用STEPとPythonソースをZIPに含めています。
'''
(R/'README_まず最初に_印刷と組立.md').write_text(readme,encoding='utf8')
ZIP='/mnt/data/ArrowsAlpha_LiveTray_v04_phone_backwall_PETG.zip'
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in sorted(R.rglob('*')):
  if f.is_file():z.write(f,arcname=str(f.relative_to(R)))
print('CREATED ZIP',ZIP,os.path.getsize(ZIP),'bytes; STL count',len(list(D.glob('*.stl'))),'tests',len(list(TEST.glob('*.stl'))))

