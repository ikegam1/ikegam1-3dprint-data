from pathlib import Path
import cadquery as cq
from cadquery import exporters
import trimesh, math,json,zipfile,shutil
P=Path('/mnt/data/ArrowsAlpha_LiveTray_v06_no_screws')
D=P/'STL';S=P/'STEP';T=P/'TEST';
for p in (D,S,T):p.mkdir(parents=True,exist_ok=True)
W=110;DEP=162;FW=6; d=3.0

def box(a,b,c,x=0,y=0,z=0):return cq.Workplane('XY').box(a,b,c).translate((x,y,z)).val()
def xz_prism(points,y0,yd):return cq.Workplane('XZ',origin=(0,y0,0)).polyline(points).close().extrude(-yd).val()
def clean(s):return s.clean()
def save(s,path,dir=D):
 b=s.BoundingBox();s=s.translate((110-(b.xmin+b.xmax)/2,110-(b.ymin+b.ymax)/2,-b.zmin))
 f=dir/path;exporters.export(s,str(f),exportType='STL',tolerance=.07,angularTolerance=.25)
 m=trimesh.load(f,force='mesh'); print(path,m.extents,m.is_watertight,'vol',round(m.volume))
 assert m.is_watertight and m.volume>0 and all(v<=220.01 for v in m.extents)
 return f

def step(s,filename):exporters.export(s,str(S/filename),exportType='STEP')

# snap-free captured side-tray rails, slide on along Y from front, end stops built into central deck.
# no thin flexible tabs: printed geometric stops + snug fit + two clip pads on rail at end
# profile cross-section: T rail attached at center edges, dimensions about 6.5mm outboard.
# rail shaft extends outward at z 3-7, head extends wider x at z6-10.

def rail_geom(side,ylen=135):
 # center is 110 wide -> x +-55. tongue protrudes from sides to +/-63.5
 x0=side*57.5
 stem=box(5.5,ylen,3.2,x0,2,5.5)
 head=box(9.0,ylen,3.0,side*60.5,2,8.55)
 return stem.fuse(head).clean()

def channel_cut(side):
 # pocket in side tray seam: channel shape inside its edge, approx 0.3mm per side clearance
 return box(6.1,140,3.8,side*57.5,4,5.5).fuse(box(9.6,140,3.6,side*60.5,4,8.6)).clean()

# Central slab 110x162, front y -81, back +81
# Floor 6mm, printing from bottom; underside integrated 70x52x9 blade,
# attached directly to underside center face with solid tapered wedge.
center=box(110,162,6,0,0,12) # slab from z9 to15
blade=box(70,52,9,0,0,4.5) # lower clamp spans 0..9 mm
# blade edges very lightly rounded for clamp comfort
try:blade=cq.Workplane(obj=blade).edges('|Z').fillet(1.2).val()
except:pass
center=center.fuse(blade)
# load distributing gussets (side of grip and near front/back)
for x in (-27,27):
 for y in (-23,23): center=center.fuse(box(12,12,3,x,y,10.5))
# Side integration tongue rails under seam; rear and front stop walls
for side in (-1,1):
 center=center.fuse(rail_geom(side,135))
# Phone dock sits behind drinks but centered: receiving printed 96x65 test part.
# phone holder base is 96 x65; side lower gripping ledges engage 4mm base plate
# install from back (+Y) sliding toward -Y. No new independent pieces.
# Dock located y roughly 6, extending y [-26.5,+38.5]. Plate sits on center slab z15.
# Two guides along x +/-48, and top retaining lips above base at z18.7
for side in (-1,1):
 # side rail external to 96 mm wide plate
 center=center.fuse(box(2.8,66,6,side*49.6,6,18))
 # retaining shelf inward 2mm, bottom clearance 4.25mm above floor
 center=center.fuse(box(2.2,58,2.0,side*47.4,3.5,20.3))
# insertion limit at front, no rear stop (slide into front edge)
center=center.fuse(box(98,3.0,5.2,0,-27.7,17.6))
# two narrow rear teeth prevent simple fall-out if rotated; can be removed with gentle lifting
# eliminate for safety if binding. Most load transmitted into shelf.
center=clean(center)
save(center,'01_CENTER_WITH_70MM_TRIPOD_GRIP_AND_PHONE_DOCK.stl');step(center,'01_CENTER_INTEGRATED.step')

# Side trays: measured effective inner footprint 108x154, approx 115x162 outer.
# plate extends from x55..170, y=-81..81. Open seam edge. female channels in protruding lip.
for side,nm in [(-1,'LEFT'),(1,'RIGHT')]:
 p=box(115,162,6,side*112.5,0,12) # z9..15
 # front / rear / outer rim, height 9 mm
 for y in (-79.2,79.2):p=p.fuse(box(115,3.6,9,side*112.5,y,19.5))
 p=p.fuse(box(3.6,162,9,side*168.2,0,19.5))
 # seam slide channel: side section removed (T profile); no hole through upper surface except mouth on seam
 p=p.cut(channel_cut(side))
 # add short track end bridge rear; blocks extrusion to reduce inadvertent sliding
 # notch end: channel opens from front y<-66 and stops at y+74; no front closure
 p=clean(p)
 save(p,f'02_{nm}_TABLE_90x140_KEYPAD.stl');step(p,f'02_{nm}_TABLE.step')

# Cup holder integrated small full-depth basket, top plane front below trays when installed.
# no hardware: clip-on two wide U-hooks riding around exposed center front edge y~-81.
# Weighted cup holder remains risky: use EMPTY ONLY until load validated.
# Render separate cup module, all within 220mm. ring top around z 0 in installed coords, hangs below tray plane
OD=89;ID=80
cup=(cq.Workplane('XY').circle(OD/2).circle(ID/2).extrude(8).translate((0,-111,-47)).val())
for i in range(8):
 theta=i*math.pi/4
 st=box(5.5,5.5,50,42.25*math.cos(theta),-111+42.25*math.sin(theta),-25)
 cup=cup.fuse(st)
# bottom lattice to support container
ring=cq.Workplane('XY').circle(OD/2).circle(ID/2).extrude(6).translate((0,-111,-2)).val()
cup=cup.fuse(ring)
for x in (-24,-8,8,24):cup=cup.fuse(box(5,75,6,x,-111,-44))
for y in (-129,-111,-93):cup=cup.fuse(box(75,5,6,0,y,-44))
# Rear hanger tongue clips attach over front wall of center shelf (y=-81 and z9..15).
for x in (-24,24):
 cup=cup.fuse(box(13,43,4,x,-73,3.5)) # bridge y -94..-51 above floor (?) sits ON shelf z 1.5..5.5, cup top at +4
 # hanger stanchions from cup ring to bridge
 cup=cup.fuse(box(13,7,52,x,-91,-21))
 # mechanical lower hook would require undercut; instead broad tongue & flat stop; captive friction
 cup=cup.fuse(box(13,5,8,x,-53,0))
# cup is experimental and needs actual load tests
cup=clean(cup)
# print basket with floor on bed and ribs standing; top hanging piece upright, total height ~58mm
save(cup,'03_FRONT_CENTER_CUP_HOLDER_EXPERIMENTAL_NO_LIQUID.stl');step(cup,'03_CUP.step')

# connector engagement test actual longitudinal sample for both sexes
sample_c=center.intersect(box(30,64,25,55,0,12.5)).clean()
sample_s=box(37,64,6,73.5,0,12).cut(channel_cut(1)).clean()
save(sample_c,'TEST_RIGHT_CENTER_RAIL_64MM.stl',T)
save(sample_s,'TEST_RIGHT_TRAY_GROOVE_64MM.stl',T)
# phone docking sample integrated into actual center part 190? center already 162; test cut central phone portion and use slide from rear
# grip test: 70x52x9 proven, not printed again separately

readme='''# arrows alpha 配信トレー v0.6 試作版 / ねじ不要

## 最初にお読みください
- v0.6は以前のM4ネジ接合をやめ、中央テーブルと70mmホルダー差し込み部を**一体化**しました。70mm板はすでに嵌合確認されています。
- 既存の **TEST_PHONE_SLOT_v04_BACKWALL_25mm_SHORT.stl から印刷した96×65mmのスマホ保持部**を、中央上面の2本のL字ガイドレールに**背面方向からスライド挿入**する設計です。
- もしお手元のスマホ保持部が短い試験片ではなく、別の形状・寸法なら、無理に挿入しないでください。
- 左右テーブルは中央との境界をT字断面のスライド接続に変更。単独ピン、ネジ、ナット、接着剤は基本不要です。ただしPETG実機公差と十分な接続強度はまだ未確認です。
- 右側・左側とも外形約115×162mm、縁内寸約108×154mm。90×140mmテンキーが入る想定です。
- ドリンクホルダーは試作品です。**荷重試験前に飲み物を載せないでください。** この接続の実荷重・転倒抵抗は未検証であり、PETG部品が破損し得ます。固定強度が不足すると判断したら取り付けないでください。

## 順番
1. TESTフォルダのスライド接続2種を印刷。プラスチックの摺動がきつければ削る程度、ゆるすぎる場合は寸法調整が必要です。
2. 中央本体（01）を印刷。ホルダーへの70mm差し込みと、既印刷の96×65mmスマホ保持パーツの接続を確認。
3. テーブル（02_RIGHT、02_LEFT）を印刷してスライド組み込み。左右トレーは開放側のレール口から通します。
4. ドリンクホルダー（03）は最後に実機確認。**水を入れた容器で強度テストしないでください。**

## PETG / Flashforge Adventurer 5M
0.4mmノズル、0.2mm積層、外壁4周、235〜245℃、ベッド75〜85℃を初期案とし、フィラメントの条件を優先します。

## 使用上の注意
- 本体の上下・向きはスライサーのプレビューで確認してください。サポートは接続レールの張り出し部分に必要な場合があります。
- 中央一体型70mmホルダー部の嵌合は以前の小テストで確認済みですが、一体本体での挟持力や三脚全体の転倒安全は未検証です。
- ドリンクホルダーは別体で、無理にはめる設計ではありません。実際の固定方法の荷重試験を済ませるまで使用しないでください。
- 現状はCAD試作版です。完成設計とみなさず、接続テストから順に進めてください。
'''
(P/'README_印刷順と注意.md').write_text(readme,encoding='utf-8')
(P/'generate_v06.py').write_text(Path(__file__).read_text(),encoding='utf-8')
Z=Path('/mnt/data/ArrowsAlpha_LiveTray_v06_no_screws_TEST_DESIGN.zip')
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED) as z:
 for f in P.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(P))
print('SUCCESS',Z,Z.stat().st_size)
